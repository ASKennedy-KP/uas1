package com.example.sesi9

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
